package ovoda_beadando_zxcjx6;
/**
 * @author kamti
 * Nev: Kamondy Tivadar
 * Neptun kod: ZXCJX6
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Teszt inditasa...\n");
        Teszt teszt = new Teszt();
        teszt.futtatas();
    }
}
