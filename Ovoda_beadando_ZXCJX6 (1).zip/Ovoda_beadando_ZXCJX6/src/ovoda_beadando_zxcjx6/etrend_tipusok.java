package ovoda_beadando_zxcjx6;
/**
 * @author kamti
 * Nev: Kamondy Tivadar
 * Neptun kod: ZXCJX6
 */
public enum etrend_tipusok {
    normal,
    liszterzekeny,
    laktoz_erzekeny,
    inzulin_rezisztencia,
    vegetarianus
}
